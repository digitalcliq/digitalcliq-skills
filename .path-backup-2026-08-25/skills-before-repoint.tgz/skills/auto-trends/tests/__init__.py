# auto-trends test package
