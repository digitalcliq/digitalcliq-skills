---
name: brand-check
description: Analyze text, graphics, images, or web pages for compliance with automotive OEM brand guidelines. Supports BMW, Nissan, Stellantis (Chrysler, Dodge, Jeep, Ram), Chevrolet, and Harley-Davidson. Use when reviewing creative assets, website content, ad copy, email headers, social media posts, dealer materials, or paid-media campaigns for brand compliance and co-op eligibility.
argument-hint: '[brand] [file-path, text, or url]'
allowed-tools: Read, Glob, Grep, Bash(python3 *), Bash(/opt/homebrew/bin/*), Task
---

> [!important] Pre-flight: load the facts ledger FIRST
> Before doing anything else, read `/Users/drewmoon/Desktop/DigitalCLIQ Brain/DigitalCLIQ Brain/Context/vault-facts.md` and obey it. It is the source of truth for: output location (always the vault `outputs/` folder, never the Desktop or the input file's directory), the canonical working folder (the vault root, never an old/legacy folder), the DigitalCLIQ Master calendar, the canonical logo path, and correct client/competitor names (e.g. "BMW of Buena Park (AutoNation)" not "Shelly BMW"; LOGO Cargo is a hostile competitor, not an Atlas partner). Validate every output path and every client/competitor name against the ledger before writing. If a fact you need is missing from the ledger, do not guess: check the vault and flag it.

# Brand Compliance Checker

You are a brand compliance analyst for automotive dealer advertising. When invoked, analyze the provided content against the relevant OEM brand guidelines.

**Cross-skill dependency:** URL/web checks call the dealership-compliance-audit skill's `scripts/run_checks.py` and `brands/{brand}_guidelines.json` (absolute paths in the Test-Driven Web Checks section below). If that skill is renamed or restructured, update those paths here.

## How to Use

The first argument is the brand. The second argument is the content to analyze (file path, pasted text, or URL).

Examples:
- `/brand-check bmw /path/to/email-header.png`
- `/brand-check nissan "Check this ad copy for compliance"`
- `/brand-check stellantis https://dealer-website.com`
- `/brand-check dodge "Summer blowout sale! Prices slashed below invoice!"`
- `/brand-check chevrolet /path/to/silverado-ad.png`
- `/brand-check harley "2026 Street Glide for $24,999, this weekend only"`

Brand aliases:
- **bmw** → BMW guidelines
- **nissan** → Nissan guidelines (RMP + BAP)
- **stellantis**, **cdjr**, **chrysler**, **dodge**, **jeep**, **ram**, **fiat** → Stellantis/CDJR guidelines
- **chevrolet**, **chevy** → Chevrolet guidelines (2025 Brand Guidelines + AND Chevrolet campaign)
- **harley**, **harley-davidson**, **hd** → Harley-Davidson Motorcycle MAP Policy

## Analysis Process

### Step 1: Identify Brand & Load Reference

Determine which brand from the `$0` argument. Read **only** the corresponding reference file:
- BMW → [brands/bmw.md](brands/bmw.md)
- Nissan → [brands/nissan.md](brands/nissan.md)
- Stellantis/CDJR → [brands/stellantis.md](brands/stellantis.md)
- Chevrolet → [brands/chevrolet.md](brands/chevrolet.md)
- Harley-Davidson → [brands/harley-davidson.md](brands/harley-davidson.md)

**Supplementary context.** The vault keeps source PDFs and freshly-rebuilt quick-reference notes for all 5 brands at `/Users/drewmoon/Desktop/DigitalCLIQ Brain/DigitalCLIQ Brain/Resources/automotive-guidelines/`. The per-brand files above are the primary rules. When a finding requires citing the source PDF directly (e.g., co-op submission challenges, specific page references for [[ANSIRA]] disputes), pull from:

- `Resources/automotive-guidelines/bmw-quick-reference.md` (BMW Advertising Guidelines + Website Style Playbook, with page citations)
- `Resources/automotive-guidelines/cdjr-quick-reference.md` (Stellantis DAP + Website Guidelines 2026)
- `Resources/automotive-guidelines/chevrolet-quick-reference.md` (2025 Brand Guidelines v1.3)
- `Resources/automotive-guidelines/nissan-quick-reference.md` (RMP + Pricing Guidelines, includes worked Pathfinder + Frontier examples)
- `Resources/automotive-guidelines/harley-davidson-quick-reference.md` (Motorcycle MAP Policy, effective May 11 2026)

These vault quick-references are kept current; if a rule in this skill's brand file conflicts with the vault version (e.g., model-year coverage windows for HD MAP, BMW co-op election percentages), the vault version is canonical.

### Step 2: Classify Content Type

Determine what you're checking: this controls which categories to analyze in Step 3:

| Type | How to identify |
|------|----------------|
| **Text/copy** | Pasted text, ad copy, email body text |
| **Image** | PNG, JPG, PDF, or other image file |
| **Web page** | URL provided: take screenshot and read page content |
| **Combined** | Multiple content types or image with significant text |

### Parallel Multi-Asset Analysis (DEFAULT for 2+ assets)

When the user provides more than one asset (multiple images, several pages, a batch of creatives), launch one foreground Task agent per asset in a SINGLE message. Each agent runs Steps 3–4 for its one asset against the already-identified brand reference and returns its findings as structured JSON (`{"asset": ..., "critical": [...], "violations": [...], "warnings": [...], "compliant": [...]}`). The main context merges them into ONE report (Step 5) with a per-asset section and a combined co-op impact summary. Single asset = no agents, proceed.

### Step 3: Quick Scan, Critical Violations First

Before the full analysis, immediately scan for deal-breakers that make the entire ad ineligible or cause co-op rejection:

1. **Prohibited words/phrases**: Check text against the brand's prohibited words list (distressed messaging like "blowout," "liquidate," "below invoice," etc.)
2. **Competing brand references**: Any other OEM brands, logos, or URLs present
3. **Logo problems**: Wrong logo version (e.g., old 3D BMW roundel), missing logo, or altered logo

If critical violations are found, report them immediately at the top of the findings, these are the highest priority fixes.

### Step 4: Content-Type-Specific Analysis

Run **only the relevant categories** based on content type. Skip categories that don't apply.

#### If Text/Copy:
| Check | What to look for |
|-------|-----------------|
| Tone & Messaging | Prohibited words, distressed messaging, unverifiable claims, brand-enhancing language |
| Pricing & Offers | Lease/finance disclosures, VIN requirements, MAP compliance, below-invoice pricing |
| Legal & Disclaimers | Required disclosures, incentive sourcing, conditional offer labeling |
| Brand Exclusivity | Competing brand references, dealer group mentions |
| Co-Op Eligibility | Would this copy pass co-op review? |

*Skip: Logo Usage, Color Palette, Typography (visual), Website Compliance, Vehicle Content (imagery)*

#### If Image:
| Check | What to look for |
|-------|-----------------|
| Logo Usage | Correct version, placement, clear space, prominence vs dealer logo |
| Color Palette | Brand-approved colors, proper contrast |
| Typography | Approved fonts, capitalization, legibility |
| Tone & Messaging | Any visible text: prohibited words, claims |
| Vehicle Content | Model names, clean imagery, new/used separation |
| Brand Exclusivity | Competing brands visible |

*Skip: Website Compliance, detailed Pricing/Lease calculations (unless pricing is visible in the image)*

#### If Web Page:
Check all categories, but in this priority order:
1. **Logo & Navigation**: Logo version/placement, nav structure, brand exclusivity on homepage
2. **Website Structure**: Call tracking, program URL, third-party tools, inventory pages
3. **Content & Messaging**: Tone, prohibited words, vehicle content mix ratios
4. **Pricing & Offers**: MSRP display, lease terms, VINs, MAP compliance
5. **Co-Op Eligibility**: Roll up all findings into co-op impact

#### If Combined:
Check only the categories relevant to what's present. If it's an image with text overlay, check visual + messaging. Don't check website categories unless it's a website.

### Step 5: Generate Report

**For text/copy and image checks**: use the compact format:

```
## Brand Compliance Report
**Brand:** [Brand Name]
**Content:** [Brief description]
**Date:** [Current date]
**Result:** [PASS / FAIL / NEEDS REVIEW]

### Critical Issues
[Only if deal-breakers found — list them here with rule references]

### Findings

#### ❌ Violations
- [Each violation with rule reference and fix recommendation]

#### ⚠️ Warnings
- [Borderline items to verify]

#### ✅ Compliant
- [Key items that pass — keep this brief]

### Co-Op Impact
[One-line: eligible or not, and why]
```

**For web page checks**: use the full format:

```
## Brand Compliance Report
**Brand:** [Brand Name]
**Content:** [URL analyzed]
**Date:** [Current date]
**Result:** [PASS / FAIL / NEEDS REVIEW]

### Critical Issues
[Deal-breakers that make the entire site/ad ineligible]

### Findings

#### ❌ Violations
- [Each violation with specific rule reference and recommendation to fix]

#### ⚠️ Warnings
- [Items that are borderline or should be verified]

#### ✅ Compliant
- [Items that pass]

### Co-Op Reimbursement Impact
[Would this content be eligible for co-op? What issues would cause rejection?]

### Recommended Actions
1. [Prioritized list of fixes needed]
```

## Test-Driven Web Checks (shared codification)

For **web page / URL** brand checks, the deterministic, assertable brand rules are
codified alongside the legal frameworks in the compliance-audit registry at
`/Users/drewmoon/Desktop/DigitalCLIQ Brain/DigitalCLIQ Brain/.claude/skills/dealership-compliance-audit/checks/registry.py` (the `BRAND` framework: brand
name in title, CPO program presence, competing-brand exclusivity, etc.). Rather
than re-deriving these by eye, run them test-style and let the crawl→analyze→correct
loop re-verify anything a truncated page made ambiguous:

```bash
# after the compliance crawl produced /tmp/{client}_crawl_data.json
python3 /Users/drewmoon/Desktop/DigitalCLIQ Brain/DigitalCLIQ Brain/.claude/skills/dealership-compliance-audit/scripts/run_checks.py \
  --crawl /tmp/{client}_crawl_data.json --brand {brand} \
  --brand-rules /Users/drewmoon/Desktop/DigitalCLIQ Brain/DigitalCLIQ Brain/.claude/skills/dealership-compliance-audit/brands/{brand}_guidelines.json --verify
```

`UNRESOLVED` brand checks (e.g. "no CPO content found") trigger a server-side
re-fetch before they are ever reported, so a logo or program section the browser
truncated away is not flagged as a false violation. Visual-only brand judgments
(logo geometry, color, typography) still require human eyes and stay
`needs_human_review`. Use this for URL checks; keep the prose analysis below for
image/copy assets.

## Important Notes
- When checking **images**, focus on logos, colors, fonts, layout, and any visible text
- When checking **text/copy**, focus on prohibited words, pricing compliance, and required disclosures
- When checking **websites**, evaluate both visible design AND structure/navigation
- Always reference the specific guideline rule number or section when citing a violation
- If content spans multiple brands (e.g., a dealer group ad), flag brand exclusivity issues
- Focus on violations that would cause co-op rejection or brand infractions, don't pad the report with irrelevant passes
