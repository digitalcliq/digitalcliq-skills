#!/usr/bin/env python3
"""Assemble the run report: merge findings + sitehealth + browser-phase results,
diff against the previous run snapshot, emit report.md (severity-grouped) and
snapshot.json for next-run diffing.

Usage:
  python3 report.py --data DATA_DIR --state STATE_DIR --out REPORT_DIR
"""
import argparse, datetime, json, os

CHECK_TITLES = {
    "C01": "Pre-rebate selling price missing (CA taxable-price rule)",
    "C02": "Doc fee excluded from advertised price (FTC all-in rule)",
    "C03": "All-in price not the most prominent price",
    "C04": "Required fee disclaimer missing/deviating",
    "C05": "Payment shown without finance disclosure",
    "C06": "No advertised price / 'Call for Price'",
    "C07": "Used price without expiration disclaimer",
    "C08": "Disclaimer mismatch or excessive length",
    "C09": "Lease/finance payment variance vs computed",
    "C10": "Current-model new vehicle missing lease payment",
    "C11": "Aged inventory at MSRP / savings math wrong",
    "C12": "Photo missing / placeholder / wrong",
    "C13": "Missing 360/spin (Impel) media",
    "C14": "Lighthouse scores / regressions",
    "C15": "Third-party script inventory issues",
    "C16": "Cookie count growth",
    "C17": "CIPA: trackers firing before consent",
    "C18": "SSL invalid/expiring",
    "C19": "Domain redirect problems",
    "C20": "Phone routing (manual verification required)",
    "C21": "Generic/placeholder phone number",
}
SEV_ORDER = [("compliance", "COMPLIANCE / LEGAL"),
             ("data_accuracy", "DATA ACCURACY"),
             ("hygiene", "PERFORMANCE / HYGIENE"),
             ("contact", "CONTACT / PHONE")]


def key(f):
    return f"{f['check']}|{f.get('vin') or f.get('url')}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--state", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    today = datetime.date.today().isoformat()

    findings = json.load(open(os.path.join(args.data, "findings.json")))
    F = findings["findings"]

    # merge browser-phase findings if the model wrote them (consent, prominence, photos)
    bp = os.path.join(args.data, "browser_findings.json")
    if os.path.exists(bp):
        F += json.load(open(bp))

    sh = {}
    shp = os.path.join(args.data, "sitehealth.json")
    if os.path.exists(shp):
        sh = json.load(open(shp))
        for r in sh.get("ssl", []):
            if r.get("flag"):
                F.append({"check": "C18", "severity": "hygiene", "url": r["host"],
                          "summary": r["flag"], "vin": None})
        for r in sh.get("redirects", []):
            if r.get("flag"):
                F.append({"check": "C19", "severity": "hygiene", "url": r["domain"],
                          "summary": f"{r['flag']} — chain: {' '.join(r['chain'][-3:])}", "vin": None})

    # Lighthouse deltas vs previous snapshot
    prev = {}
    prev_path = os.path.join(args.state, "snapshot.json")
    if os.path.exists(prev_path):
        prev = json.load(open(prev_path))
    prev_lh = {r["url"]: r for r in prev.get("lighthouse", [])}
    for r in sh.get("lighthouse", []):
        if "error" in r:
            continue
        pl = prev_lh.get(r["url"], {})
        drops = [f"{c} {pl[c]}->{r[c]}" for c in ("performance", "seo", "accessibility", "best-practices")
                 if c in r and c in pl and r[c] < pl[c] - 4]
        if r.get("performance", 100) < 50 or drops:
            F.append({"check": "C14", "severity": "hygiene", "url": r["url"], "vin": None,
                      "summary": f"Lighthouse perf {r.get('performance')}" +
                                 (f"; regressions: {', '.join(drops)}" if drops else "")})

    # week-over-week diff
    prev_keys = set(prev.get("finding_keys", []))
    cur_keys = {key(f) for f in F}
    new_keys, resolved_keys = cur_keys - prev_keys, prev_keys - cur_keys
    for f in F:
        f["status"] = "NEW" if key(f) in new_keys and prev_keys else ("PERSISTING" if prev_keys else "BASELINE")

    # ---- render markdown ----
    L = [f"# McPeek's CDJR — Site Watch Report — {today}",
         "",
         f"Crawled {findings.get('vehicle_count', '?')} VDPs. "
         f"{len(F)} findings ({len(new_keys) if prev_keys else 'baseline run — all'} new, "
         f"{len(resolved_keys)} resolved since last run).", ""]

    counts = {}
    for f in F:
        counts[f["check"]] = counts.get(f["check"], 0) + 1
    L.append("| Check | Findings |\n|---|---|")
    for c in sorted(counts):
        L.append(f"| {c} — {CHECK_TITLES.get(c, c)} | {counts[c]} |")
    L.append("")

    for sev, title in SEV_ORDER:
        group = [f for f in F if f["severity"] == sev]
        if not group and sev != "contact":
            continue
        L.append(f"## {title}\n")
        by_check = {}
        for f in group:
            by_check.setdefault(f["check"], []).append(f)
        for c in sorted(by_check):
            items = by_check[c]
            L.append(f"### {c} — {CHECK_TITLES.get(c, c)}  ({len(items)})\n")
            for f in items[:60]:
                vin = f" `{f['vin']}`" if f.get("vin") else ""
                st = f" **[{f['status']}]**" if f.get("status") not in (None, "BASELINE") else ""
                L.append(f"- {f['summary']}{vin}{st}\n  {f['url']}")
                if f.get("detail"):
                    L.append(f"  - {str(f['detail'])[:220]}")
            if len(items) > 60:
                L.append(f"- …and {len(items) - 60} more (full list in findings.json)")
            L.append("")
        if sev == "contact":
            L.append("### C20 — Manual call verification checklist\n")
            L.append("Claude cannot place phone calls. Call each number below and confirm: "
                     "correct department queue, no CallRevu/whisper before connect.\n")
            for ph, pages in findings.get("phones_sitewide", {}).items():
                L.append(f"- [ ] {ph} — seen on: {', '.join(map(str, pages))[:120]}")
            L.append("")

    if resolved_keys:
        L.append("## Resolved since last run\n")
        for k in sorted(resolved_keys):
            L.append(f"- {k}")
        L.append("")

    if sh.get("lighthouse"):
        L.append("## Lighthouse scores\n")
        L.append("| Page | Perf | SEO | A11y | Best Practices | LCP |\n|---|---|---|---|---|---|")
        for r in sh["lighthouse"]:
            if "error" in r:
                L.append(f"| {r['url']} | error | | | | |")
            else:
                L.append(f"| {r['url']} | {r.get('performance')} | {r.get('seo')} | "
                         f"{r.get('accessibility')} | {r.get('best-practices')} | {r.get('lcp_s')}s |")
        L.append("")

    os.makedirs(args.out, exist_ok=True)
    report_path = os.path.join(args.out, f"McPeeks_Site_Watch_{today}.md")
    with open(report_path, "w") as f:
        f.write("\n".join(L))

    snapshot = {"date": today, "finding_keys": sorted(cur_keys),
                "counts": counts, "lighthouse": sh.get("lighthouse", []),
                "vehicle_count": findings.get("vehicle_count")}
    with open(os.path.join(args.state, "snapshot.json"), "w") as f:
        json.dump(snapshot, f, indent=1)
    # archive dated snapshot for history
    os.makedirs(os.path.join(args.state, "history"), exist_ok=True)
    with open(os.path.join(args.state, "history", f"{today}.json"), "w") as f:
        json.dump(snapshot, f)

    print(report_path)


if __name__ == "__main__":
    main()
