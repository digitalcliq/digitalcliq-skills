# California Advertising Law: AI Judgment Criteria

These are gray-area assessments where binary pass/fail is not possible. The AI auditor should evaluate each item and assign a severity:
- **Warning** (likely violation, needs attorney review)
- **Advisory** (best practice concern, low legal risk)

## Contents

- [1. Clear and Conspicuous Standard](#1-clear-and-conspicuous-standard)
- [2. Puffery vs. Factual Claims](#2-puffery-vs-factual-claims)
- [3. Payment Advertising Adequacy](#3-payment-advertising-adequacy)
- [4. Rebate Stacking Disclosure](#4-rebate-stacking-disclosure)
- [5. Sale / Savings Language Substantiation](#5-sale--savings-language-substantiation)
- [6. Digital Disclaimer Adequacy](#6-digital-disclaimer-adequacy)
- [7. Lease "Due at Signing" Accuracy](#7-lease-due-at-signing-accuracy)
- [8. Vehicle History / Condition Representations](#8-vehicle-history--condition-representations)
- [9. Environmental / Fuel Economy Claims](#9-environmental--fuel-economy-claims)
- [10. Privacy Policy Completeness (CCPA/CPRA)](#10-privacy-policy-completeness-ccpacpra)
- [11. Data Collection & Financial Incentive Practices (CCPA/CPRA)](#11-data-collection--financial-incentive-practices-ccpacpra)
- [12. CARS Act: Add-On Presentation and Disclosure Adequacy](#12-cars-act--add-on-presentation-and-disclosure-adequacy)
- [13. CARS Act: 3-Day Cancellation Right Disclosure Prominence](#13-cars-act--3-day-cancellation-right-disclosure-prominence)
- [14. CARS Act: Total Price and Payment Disclosure Clarity](#14-cars-act--total-price-and-payment-disclosure-clarity)
- [15. CARS Act: Waiver and Anti-Cancellation Language](#15-cars-act--waiver-and-anti-cancellation-language)
- [Confidence Level System](#confidence-level-system)
- [Severity Assignment Guide](#severity-assignment-guide)

## 1. Clear and Conspicuous Standard

**Context:** California law requires disclosures to be "clear and conspicuous" but does not prescribe exact font sizes for most disclosures (VC §11713.16(i)).

**Evaluate for:**
- Font size relative to surrounding text, disclosures in significantly smaller type than the claim they qualify
- Contrast: light gray text on white background, or similar low-contrast combinations
- Placement: disclosures at the bottom of the page far from the claim, or requiring scrolling
- Clickability: disclosures hidden behind hover-overs, asterisks leading to footnotes several screens away, or requiring a click to expand
- Duration: on video/animated ads, disclosures that flash too briefly to read
- Proximity: qualifying disclosures not near the claim they modify

**Flag as Warning when:** Disclosure exists but is likely unreadable by a reasonable consumer (e.g., 6px font, extreme scroll distance, 2-second flash in video).

**Flag as Advisory when:** Disclosure is present and technically readable but could be more prominent.

## 2. Puffery vs. Factual Claims

**Context:** "Puffery" (subjective opinions) is legal; factual claims require substantiation (CA B&P Code §17508).

**Evaluate for:**
- Subjective/opinion claims (LEGAL puffery): "Great deals," "Amazing service," "You'll love our selection"
- Factual/verifiable claims (REQUIRE substantiation): "#1 dealer in volume," "Lowest prices in SoCal," "Highest customer satisfaction," "Best resale value"
- Borderline claims: "Unbeatable prices" (could be read as factual), "Southern California's favorite dealer" (implies ranking)

**Flag as Warning when:** A claim is presented as factual (uses numbers, rankings, superlatives implying measurability) without visible substantiation or source citation.

**Flag as Advisory when:** A borderline claim could be read either way by a reasonable consumer.

## 3. Payment Advertising Adequacy

**Context:** Monthly payment ads are heavily scrutinized. Even when Reg Z/M disclosures are technically present, the overall impression matters.

**Evaluate for:**
- Large, bold monthly payment with tiny disclosure text far below
- Payment amount highlighted in hero banner while required terms are in footer
- Payment shown without context (what vehicle, what term, what conditions)
- Multiple payment offers on one page creating confusion about which disclosures apply to which vehicle
- "Starting at $X/mo" without clear identification of which specific vehicle

**Flag as Warning when:** Required disclosures are technically present but the overall ad impression could mislead a reasonable consumer about the true cost.

**Flag as Advisory when:** Disclosure layout could be improved but is unlikely to mislead.

## 4. Rebate Stacking Disclosure

**Context:** Many dealers stack multiple rebates/incentives to reach an advertised price. Each rebate may have different qualifications.

**Evaluate for:**
- Multiple rebates deducted from price (loyalty, conquest, military, college grad, etc.)
- Whether each rebate's qualification criteria are disclosed
- Whether the customer could realistically qualify for ALL stacked rebates simultaneously
- Whether "net price" language clearly shows which rebates are included
- Conditional rebates (e.g., must finance with manufacturer) presented as universal discounts

**Flag as Warning when:** Price includes multiple conditional rebates and qualifications are not clearly disclosed, or it's unrealistic for most consumers to qualify for all of them.

**Flag as Advisory when:** Rebate qualifications are disclosed but could be more prominent.

## 5. Sale / Savings Language Substantiation

**Context:** "Sale" implies a temporary price reduction from a genuine prior price (B&P Code §17501).

**Evaluate for:**
- "Sale" without visible start/end dates
- Perpetual "sale" pricing (always on sale = never actually reduced)
- Savings claims ("Save $5,000 off MSRP"), is MSRP a fair reference for "savings"?
- "Clearance" or "blowout" language on current model-year vehicles
- Percentage-off claims without clear reference price

**Flag as Warning when:** Sale/savings claims appear to be perpetual, lack dates, or reference prices that don't represent genuine prior selling prices.

**Flag as Advisory when:** Sale dates are present but the reference price could be questioned.

## 6. Digital Disclaimer Adequacy

**Context:** Website-specific concerns about how disclaimers are implemented in digital formats.

**Evaluate for:**
- Asterisk (*) disclaimers: does the asterisk clearly link to the corresponding disclosure?
- Scroll distance: how far must the user scroll to find the qualifying disclosure?
- Pop-up/overlay disclaimers: are they accessible and readable?
- Mobile responsiveness: are disclosures that work on desktop still readable on mobile?
- Dynamic content: do rotating banners/carousels show required disclosures for sufficient time?

**Flag as Warning when:** A reasonable user would not find or read the disclaimer in normal browsing behavior.

**Flag as Advisory when:** Disclaimers are accessible but require extra effort to find.

## 7. Lease "Due at Signing" Accuracy

**Context:** Lease ads commonly emphasize low monthly payments while downplaying the total due at signing.

**Evaluate for:**
- Total due at signing prominently displayed vs. buried
- Whether "due at signing" amount includes first month's payment, acquisition fee, cap cost reduction, etc.
- "$0 due at signing" claims when security deposits, first payment, or fees are actually required
- Whether the equal prominence rule is followed (down payment amount not more prominent than total due at signing)

**Flag as Warning when:** Due-at-signing amount appears misleading or the $0 claim is contradicted by actual terms.

**Flag as Advisory when:** Due-at-signing is disclosed but formatting gives disproportionate weight to the low monthly payment.

## 8. Vehicle History / Condition Representations

**Context:** Representations about used vehicle condition and history carry legal weight.

**Evaluate for:**
- "Clean title" or "no accidents" claims, can the dealer substantiate this?
- Vehicle history descriptions that omit known prior use (rental, fleet, etc.)
- "Like new" or "pristine condition" for vehicles with known issues
- Certified pre-owned claims for vehicles that may have disqualifying conditions

**Flag as Warning when:** Specific factual claims about history/condition are made that the dealer may not be able to substantiate.

**Flag as Advisory when:** Language is vague enough to be subjective but could create expectations.

## 9. Environmental / Fuel Economy Claims

**Context:** EV range and fuel economy claims have specific FTC guidance.

**Evaluate for:**
- General MPG/range claims without EPA estimates
- "Best in class" fuel economy without substantiation
- EV range claims that don't clarify EPA-estimated range
- Hybrid claims that mix city/highway in misleading ways

**Flag as Warning when:** Fuel economy or range claims lack required EPA disclosures or misrepresent the metric.

**Flag as Advisory when:** Claims are technically correct but could be clearer about EPA basis.

## 10. Privacy Policy Completeness (CCPA/CPRA)

**Context:** CCPA/CPRA requires privacy policies to include specific content sections, but the depth and specificity of each section can vary. A privacy policy may technically mention a topic but provide inadequate detail.

**Evaluate for:**
- Consumer rights section: does it describe ALL five rights (know, delete, correct, opt-out, limit) or only some?
- Categories of PI: does it list specific categories relevant to a dealership (name, email, phone, IP address, browsing history, vehicle preferences, financial information) or use vague language?
- Third-party disclosures: does it name categories of third parties (ad networks, analytics providers, CRM platforms, lead aggregators) or just say "third parties"?
- Sell/share disclosure: does it clearly state whether PI is sold or shared for behavioral advertising, or is this ambiguous?
- Retention periods: does it specify actual time periods or just say "as long as necessary"?
- GPC signal disclosure: does it clearly state whether GPC signals are honored?
- Request submission methods: does it provide at least 2 clear methods (toll-free phone + email/web form)?
- Last updated date: is the privacy policy current (within 12 months)?

**Flag as Warning when:** Privacy policy exists but is missing 3+ required content sections, or the last updated date is more than 12 months old, or consumer request methods are missing/unclear.

**Flag as Advisory when:** Privacy policy covers most topics but 1-2 sections are vague or could be more specific (e.g., generic third-party language, no specific retention periods).

## 11. Data Collection & Financial Incentive Practices (CCPA/CPRA)

**Context:** Dealership websites routinely collect personal information through lead forms, chat widgets, finance applications, and trade-in calculators. When a benefit (like an "internet price" or trade-in estimate) is offered in exchange for PI, CCPA/CPRA may classify this as a "financial incentive" requiring specific disclosures.

**Evaluate for:**
- Lead forms that gate pricing behind contact info submission ("Get Your ePrice", "Unlock Internet Price", "Submit for Best Price")
- Trade-in value tools that require PI before showing estimates
- Chat widgets that collect name/email/phone before connecting to an agent
- Finance pre-qualification forms collecting SSN, DOB, or income
- Whether any notice at collection appears near or within these forms
- Whether the privacy policy mentions financial incentive programs
- Pop-ups or modals that require email/phone before allowing site interaction

**Flag as Warning when:** Website clearly gates pricing or significant benefits behind PI submission without any financial incentive disclosure or notice at collection near the form.

**Flag as Advisory when:** Lead forms exist and collect PI but don't appear to condition benefits on submission (e.g., general "Contact Us" forms), or notice at collection is present but could be more prominent.

## 12. CARS Act: Add-On Presentation and Disclosure Adequacy

**Context:** The CARS Act (SB 766, operative October 1, 2026) requires dealers to clearly and conspicuously disclose in writing that add-on products/services are not required. On dealer websites, add-ons may be presented in ways that blur the line between optional and required.

**Evaluate for:**
- Add-on products presented in vehicle build/configure tools, are they pre-selected by default?
- Add-on packages bundled into the vehicle price without clear separation or "optional" labeling
- Language implying add-ons are required (e.g., "includes dealer protection package" without "optional" disclaimer)
- F&I product descriptions that emphasize necessity or urgency ("Don't drive without GAP coverage")
- Service contracts, nitrogen tire fill, paint protection, theft deterrent, are these clearly presented as optional?
- If add-ons are pre-checked in online purchase/build tools, does the consumer clearly understand they can decline?
- Prohibited valueless add-ons listed on EVs (oil change packages) or vehicles without catalytic converters (cat marking)

**Flag as Warning when:** Add-on products are presented in a way that a reasonable consumer would believe they are required, or pre-selected add-ons cannot be easily removed in the online configuration. Also flag if prohibited valueless add-ons are offered for incompatible vehicles (e.g., oil changes for EVs).

**Flag as Advisory when:** Add-ons are clearly optional but the "not required" disclosure could be more prominent or is positioned far from the add-on selection.

## 13. CARS Act: 3-Day Cancellation Right Disclosure Prominence

**Context:** The CARS Act grants a 3-day right to cancel for used vehicles $50,000 or less. While the primary disclosure is a separate document provided at sale, dealer websites should reference this right on used vehicle pages so consumers are aware before visiting the dealership.

**Evaluate for:**
- Used vehicle listing pages (VLP): is there any reference to the 3-day cancellation right?
- Used vehicle detail pages (VDP): is the cancellation right mentioned?
- FAQ or policy pages: do they explain the 3-day right accurately?
- "All sales final" language that contradicts the statutory cancellation right
- Whether the cancellation right is described with accurate terms (3 calendar days, $50K threshold, restocking fee, 400-mile limit)
- Whether restocking fee information matches statutory limits (1.5% / $200-$600 / $1 per mile over 250)
- Whether any language attempts to discourage consumers from exercising cancellation rights

**Flag as Warning when:** Used vehicle pages contain language that contradicts the 3-day cancellation right (e.g., "all sales final"), or FAQ/policy pages describe cancellation terms that don't match the CARS Act requirements (wrong fee amounts, wrong timeframes, etc.).

**Flag as Advisory when:** Used vehicle pages don't mention the cancellation right at all (since the primary disclosure is at point of sale, absence on website is a best-practice concern rather than a violation, unless the website contains contradictory language).

## 14. CARS Act: Total Price and Payment Disclosure Clarity

**Context:** The CARS Act requires total price in all vehicle-specific advertisements and, when advertising monthly payments, requires disclosure of the total amount payable over the loan/lease term. For digital advertising on dealer websites, the presentation matters.

**Evaluate for:**
- Is the "total price" the most prominent price shown, or is a lower teaser price (after rebates, conditional discounts) more prominent?
- Monthly payment advertisements: is the total amount payable disclosed clearly and conspicuously?
- Are total payable amounts in fine print or footnotes while the monthly payment is in large bold text?
- Does the payment advertisement factor in a downpayment or trade-in without disclosing those amounts?
- "Lower your payment" messaging: does it include the required warning about extended terms increasing total cost?
- Payment calculator tools (exempt from the extended-term warning), are they clearly interactive tools vs. static advertisements?
- Are there inconsistencies between the total price shown in inventory listings vs. vehicle detail pages?

**Flag as Warning when:** Monthly payments are prominently advertised without the total payable amount visible, or the total payable is buried in fine print far from the monthly payment claim. Also flag if "lower payment" messaging lacks the extended-term cost warning.

**Flag as Advisory when:** Total price and payment disclosures exist but could be more prominently displayed relative to the monthly payment amounts.

## 15. CARS Act: Waiver and Anti-Cancellation Language

**Context:** The CARS Act voids any consumer waiver of CARS Act rights. Website terms of service, purchase policies, and arbitration clauses cannot require consumers to waive cancellation rights, add-on disclosure rights, or other CARS Act protections.

**Evaluate for:**
- Terms of service or website policies that include blanket waiver language
- Return/cancellation policy pages that attempt to limit the statutory 3-day right
- Arbitration clauses that attempt to cover CARS Act disputes
- "As-Is" sale language on used vehicles that could be interpreted as waiving cancellation rights
- Language requiring consumers to agree to forgo cancellation rights as a condition of purchase
- Pop-ups or checkboxes requiring agreement to terms that may conflict with CARS Act protections

**Flag as Warning when:** Website terms or policies contain language that directly conflicts with or attempts to waive CARS Act consumer protections.

**Flag as Advisory when:** Terms are ambiguous and could be interpreted as limiting CARS Act rights, but don't explicitly waive them.

---

## Confidence Level System

Every finding MUST include a confidence level:

- **high**: The finding is based on clear textual evidence (regex match, boolean flag, exact text found). No human review needed.
- **medium**: The finding is based on partial evidence or the AI could not fully verify (e.g., disclaimers may be behind click-to-expand buttons, popups may have blocked extraction, visual layout cannot be assessed). **MUST include "NEEDS HUMAN REVIEW AND VERIFICATION" in the recommendation.**
- **low**: The finding is speculative or based on absence of evidence that may exist but was not captured. **MUST include "NEEDS HUMAN REVIEW AND VERIFICATION" in the recommendation.** Consider downgrading severity to advisory.

### When to assign medium/low confidence:
- Any claim about visual layout, font size, prominence, or placement (the AI cannot see the page layout)
- Any claim about disclaimers being "missing" when the page has expandable/collapsed content
- Any claim about content being "hidden" or "buried" when popups or chat widgets may have blocked extraction
- Any claim about color, contrast, or visual hierarchy
- Any finding where a popup, chat widget, or overlay may have interfered with page data extraction

### Required format for medium/low confidence findings:
The recommendation field MUST start with: **"NEEDS HUMAN REVIEW AND VERIFICATION"** followed by an explanation of why the automated audit could not fully verify this finding, then the actual recommendation.

---

## Severity Assignment Guide

When evaluating gray areas, consider:

1. **Consumer Impact**: How likely is a reasonable consumer to be misled?
2. **Financial Impact**: Could the issue cause the consumer financial harm?
3. **Regulatory Risk**: How likely would a DMV investigator or DA flag this?
4. **Privacy Risk**: How likely would the CA AG's Privacy Protection Office investigate this?
5. **Pattern**: Is this a one-off issue or systemic across the site?

**Critical** = ONLY use when 110% certain. Clear, unambiguous violation with textual evidence.
**Warning** = High consumer impact OR high regulatory risk. Use for gray-area concerns.
**Advisory** = Low impact, best-practice improvement. Use when uncertain.

**IMPORTANT**: Never assign "critical" severity unless you have concrete, unambiguous textual evidence. If there is ANY doubt, use "warning" or "advisory" instead. It is far better to under-flag than to produce a false critical finding that undermines the report's credibility.
