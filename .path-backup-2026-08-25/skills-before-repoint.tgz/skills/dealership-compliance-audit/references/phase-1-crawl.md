## Phase 1: Crawl & Extract Page Data

> [!important] Crawl the CASCADE, never grind on one method
> Dealer sites are commonly anti-scraper (WAF 403s on server fetch) AND ship heavy
> front-ends (Dealer Inspire / Cars.com VDPs and inventory-search VLPs can hard-hang
> a browser renderer). Do NOT keep retrying the surface that just failed. Cascade the
> moment a method stalls twice:
> 1. **Built-in browser** (`Claude_Browser` in-app pane), no auth, default. If a page
>    hangs the pane (stops compositing / eval times out), recover with a fresh
>    `preview_start` tab. If a specific page hangs on ~2 fresh attempts, it will keep
>    hanging: move on, do not loop.
> 2. **Real Chrome via the extension** (`claude-in-chrome`): needs a one-time user
>    approval, but it is a full logged-in browser that sails past most WAFs and heavy
>    pages. Reach for it EARLY when the built-in pane is fighting a site, not as a last
>    resort. (`list_connected_browsers` → ask which browser → `select_browser`.)
> 3. **Server fetch** (`scripts/fallback_crawl.py`): zero-token, but 403s on
>    scraper-blocking WAFs. Text-only pages (finance) only.
> 4. **Lighter/curated pages**: when full inventory-search VLPs and VDPs hang, the
>    curated specials listings (`/new-vehicles/new-vehicle-specials/`,
>    `/used-vehicles/pre-owned-vehicle-specials/`) carry full per-vehicle pricing + VINs
>    and load reliably; use them for VDP-level pricing and record blocked per-VDP
>    disclaimer extraction as needs-human-review, never as a violation.
>
> The point: try more than one way, every time. A stalled crawl is a signal to switch
> surfaces, not to retry.

**PARALLEL CRAWL (DEFAULT):** The page types below (homepage, specials, VLP, the
sampled VDPs, used/CPO, finance, privacy policy) are independent, crawl them
concurrently, not in sequence. Launch one foreground Task agent per page type in a
SINGLE message. Each agent creates its OWN browser tab via `tabs_create_mcp`,
navigates to its page, and runs its JS extractor.

**TOKEN DISCIPLINE: agents write fragments to disk, they do NOT return page text.**
Each crawl agent writes its extracted JSON straight to
`/tmp/{safe_client}_page_{pagekey}.json` and returns to the main context ONLY a
one-line status, never the page body. For example:
`specials: ok — 4,210 chars, 6 disclaimers, 3 expand buttons clicked` or
`privacy_policy: error — 404`. The 12K–15K-char excerpts stay on disk where the
Python engine reads them; they must never flow back through the main context. This
is the single biggest token cost in the whole audit, keep it on disk.

A page that blocks or 404s writes `{"page": ..., "error": "<reason>"}` to its
fragment file: the audit proceeds and the gap is recorded as a finding, never
papered over. (Phase 2c stays a SINGLE focused agent by design, do not fan it out;
the token consolidation there is intentional.)

**Server-fetch the text-only pages to save a browser tab.** The `finance` page is
pure text signal (no JS galleries, no expand buttons). You may fetch it server-side
with zero browser and zero tokens instead of spending a browser agent on it:
`python3 scripts/fallback_crawl.py --page finance --url <finance_url> --out /tmp/{safe_client}_page_finance.json`.
Keep the browser for homepage (privacy/forms), specials (expand buttons), VLP/used
(JS inventory), and the sampled VDPs, where structured DOM extraction matters.

This phase uses the browser to crawl the dealership website and extract structured data from each key page. All data is saved to a single JSON file for the analysis agents.

### Step 1.1: Get Browser Context and Navigate to Homepage

```
tabs_context_mcp → get tab ID
navigate to <url> → wait 3 seconds
```

### Step 1.2: Discover Navigation URLs

Use `javascript_tool` on the homepage to extract all nav links. This avoids 404 errors from guessing URLs:

```javascript
// Extract all navigation links from the site
Array.from(document.querySelectorAll('nav a, [role="navigation"] a, header a'))
  .map(a => ({ text: a.textContent.trim(), href: a.href }))
  .filter(l => l.href.startsWith(window.location.origin) && l.text.length > 0)
  .reduce((acc, l) => {
    if (!acc.find(x => x.href === l.href)) acc.push(l);
    return acc;
  }, [])
  .slice(0, 50)
```

From the nav links, identify these target pages:
- **specials**: URL containing "special", "offers", "deals", or "lease"
- **new_inventory**: URL containing "new-vehicles", "new-inventory", or "new"
- **used_inventory**: URL containing "used", "pre-owned", or "preowned"
- **cpo**: URL containing "certified", "cpo"
- **finance**: URL containing "finance", "financing", "credit"
- **privacy_policy**: Detected from homepage extraction `privacy.privacy_policy_url` (may be in footer, not nav)

### Step 1.3: Extract Data from Each Page

**CRITICAL: Use `javascript_tool` for ALL page data extraction.** Do NOT use `get_page_text` or `read_page`, these fail on large inventory pages.

For each discovered page: navigate, wait 2 seconds, then run that page type's extraction
JS from `references/page-extraction.md` (one section per page type, each crawl agent
reads ONLY the section for its page type):

- **Homepage**: pricing claims, disclaimers, privacy/footer links, lead-form consent signals
- **VLP (new inventory)**: listing pricing, strike-through/discount claims
- **VDP: RANDOM MULTI-SAMPLE**, sampling rules plus per-vehicle extraction; every sampled VDP gets the full extraction
- **Specials page**: offer tiles, expand-button clicks, disclaimer capture
- **Used/CPO page**: used listing pricing and certification claims
- **Finance page**: text-only signal (may be server-fetched, see the Phase 1 note above)
- **Privacy policy**: CCPA/CPRA signals, GPC disclosure, financial-incentive notice, request methods


### Step 1.4: Save Crawl Data

Assemble all extracted page data into a single JSON object and write to `/tmp/{safe_client}_crawl_data.json`:

```json
{
  "url": "https://www.sterlingbmw.com",
  "brand": "bmw",
  "client": "Sterling BMW",
  "crawl_date": "2026-03-05",
  "vdp_sample_meta": {
    "candidates_found": 28,
    "sampled": [
      {"page_key": "vdp",   "vin": "WBA...ABCD", "url": "https://.../inventory/new-2026-...", "condition": "new"},
      {"page_key": "vdp_2", "vin": "5N1...WXYZ", "url": "https://.../inventory/used-2023-...", "condition": "used"},
      {"page_key": "vdp_3", "vin": "1C4...QRST", "url": "https://.../inventory/new-2026-...", "condition": "new"}
    ]
  },
  "pages": {
    "homepage": { ... },
    "specials": { ... },
    "vlp": { ... },
    "vdp": { ... },
    "vdp_2": { ... },
    "vdp_3": { ... },
    "used": { ... },
    "cpo": { ... },
    "finance": { ... },
    "privacy_policy": { ... }
  }
}
```

Where `safe_client` = client name lowercased with spaces replaced by underscores.
`vdp`, `vdp_2`, `vdp_3`, ... are the randomly-sampled vehicle detail pages; every
per-vehicle check runs against all of them.

**If a page fails to load or returns a 404**, set its value to `{"error": "404", "url": "..."}` and move on. Do NOT retry or guess alternate URLs, use only URLs discovered from the nav in Step 1.2.

---
